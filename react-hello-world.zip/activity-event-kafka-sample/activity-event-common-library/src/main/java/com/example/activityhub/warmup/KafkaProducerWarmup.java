package com.example.activityhub.warmup;

import com.example.activityhub.config.ActivityHubKafkaProperties;
import com.example.activityhub.model.ActivityEventMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.kafka.core.KafkaTemplate;

public class KafkaProducerWarmup implements ApplicationRunner {

    private static final Logger logger =
            LoggerFactory.getLogger(KafkaProducerWarmup.class);

    private final KafkaTemplate<String, ActivityEventMessage> kafkaTemplate;
    private final ActivityHubKafkaProperties properties;

    public KafkaProducerWarmup(
            KafkaTemplate<String, ActivityEventMessage> kafkaTemplate,
            ActivityHubKafkaProperties properties) {

        this.kafkaTemplate = kafkaTemplate;
        this.properties = properties;
    }

    @Override
    public void run(ApplicationArguments args) {

        if (!properties.isWarmupEnabled()) {
            logger.info("Kafka producer warm-up is disabled");
            return;
        }

        long startedAt = System.currentTimeMillis();

        try {
            kafkaTemplate.execute(producer -> {
                producer.partitionsFor(properties.getTopic());
                return null;
            });

            logger.info(
                    "Kafka producer warm-up completed. topic={}, durationMs={}",
                    properties.getTopic(),
                    System.currentTimeMillis() - startedAt
            );
        } catch (Exception exception) {
            // Do not prevent the application from starting.
            logger.warn(
                    "Kafka producer warm-up failed. Application will continue. topic={}",
                    properties.getTopic(),
                    exception
            );
        }
    }
}
