package com.example.activityconsumer.listener;

import com.example.activityconsumer.service.ActivityEventPersistenceService;
import com.example.activityhub.model.ActivityEventMessage;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
public class ActivityEventKafkaListener {

    private static final Logger logger =
            LoggerFactory.getLogger(ActivityEventKafkaListener.class);

    private final ActivityEventPersistenceService persistenceService;

    public ActivityEventKafkaListener(
            ActivityEventPersistenceService persistenceService) {
        this.persistenceService = persistenceService;
    }

    @KafkaListener(
            topics = "${activityhub.kafka.topic}",
            groupId = "${activityhub.kafka.consumer.group-id}",
            containerFactory = "activityEventKafkaListenerContainerFactory"
    )
    public void consume(
            ConsumerRecord<String, ActivityEventMessage> record) {

        ActivityEventMessage event = record.value();

        logger.info(
                "Activity event received. eventId={}, topic={}, partition={}, offset={}, thread={}",
                event == null ? null : event.getEventId(),
                record.topic(),
                record.partition(),
                record.offset(),
                Thread.currentThread().getName()
        );

        /*
         * Do not catch and swallow exceptions here.
         *
         * A database outage or unexpected persistence error must propagate
         * to Spring Kafka so the DefaultErrorHandler retries and eventually
         * sends the record to the DLT.
         */
        persistenceService.saveIdempotently(event);
    }
}
