package com.example.activityhub.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ActivityEvent {

    String eventName();

    String category() default "";

    String entityType() default "";

    String contactType() default "";

    String entityIdArg() default "";

    String contactIdArg() default "";

    String source() default "";
}
