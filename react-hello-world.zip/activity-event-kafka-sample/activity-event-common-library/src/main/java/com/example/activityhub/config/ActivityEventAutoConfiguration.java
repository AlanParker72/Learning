package com.example.activityhub.config;

import com.example.activityhub.aspect.ActivityEventAspect;
import com.example.activityhub.model.ActivityEventMessage;
import com.example.activityhub.publisher.ActivityEventPublisher;
import com.example.activityhub.publisher.KafkaActivityEventPublisher;
import com.example.activityhub.warmup.KafkaProducerWarmup;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.EnableAsync;

@AutoConfiguration(after = ActivityEventKafkaConfiguration.class)
@EnableAsync
@ConditionalOnProperty(
        name = "activityhub.enabled",
        havingValue = "true",
        matchIfMissing = true
)
public class ActivityEventAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public ActivityEventPublisher activityEventPublisher(
            @Qualifier("activityEventKafkaTemplate")
            KafkaTemplate<String, ActivityEventMessage> kafkaTemplate,
            ActivityHubKafkaProperties properties) {

        return new KafkaActivityEventPublisher(
                kafkaTemplate,
                properties
        );
    }

    @Bean
    @ConditionalOnMissingBean
    public ActivityEventAspect activityEventAspect(
            ActivityEventPublisher publisher) {

        return new ActivityEventAspect(publisher);
    }

    @Bean
    @ConditionalOnBean(name = "activityEventKafkaTemplate")
    @ConditionalOnMissingBean
    public KafkaProducerWarmup kafkaProducerWarmup(
            @Qualifier("activityEventKafkaTemplate")
            KafkaTemplate<String, ActivityEventMessage> kafkaTemplate,
            ActivityHubKafkaProperties properties) {

        return new KafkaProducerWarmup(
                kafkaTemplate,
                properties
        );
    }
}
