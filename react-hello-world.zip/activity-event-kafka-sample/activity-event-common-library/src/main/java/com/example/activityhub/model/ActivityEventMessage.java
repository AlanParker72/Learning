package com.example.activityhub.model;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class ActivityEventMessage {

    private String eventId;
    private Instant eventDate;
    private String eventName;
    private String category;
    private String entityType;
    private String entityId;
    private String contactType;
    private String contactId;
    private String source;
    private String sessionId;
    private Map<String, Object> payload = new LinkedHashMap<>();

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public Instant getEventDate() {
        return eventDate;
    }

    public void setEventDate(Instant eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getEntityId() {
        return entityId;
    }

    public void setEntityId(String entityId) {
        this.entityId = entityId;
    }

    public String getContactType() {
        return contactType;
    }

    public void setContactType(String contactType) {
        this.contactType = contactType;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public Map<String, Object> getPayload() {
        return payload;
    }

    public void setPayload(Map<String, Object> payload) {
        this.payload = payload;
    }

    @Override
    public String toString() {
        return "ActivityEventMessage{" +
                "eventId='" + eventId + '\'' +
                ", eventDate=" + eventDate +
                ", eventName='" + eventName + '\'' +
                ", category='" + category + '\'' +
                ", entityType='" + entityType + '\'' +
                ", entityId='" + entityId + '\'' +
                ", contactType='" + contactType + '\'' +
                ", contactId='" + contactId + '\'' +
                ", source='" + source + '\'' +
                ", sessionId='" + sessionId + '\'' +
                ", payload=" + payload +
                '}';
    }
}
