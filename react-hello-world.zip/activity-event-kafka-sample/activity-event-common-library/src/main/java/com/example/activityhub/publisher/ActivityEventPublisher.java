package com.example.activityhub.publisher;

import com.example.activityhub.model.ActivityEventMessage;

public interface ActivityEventPublisher {

    void publish(ActivityEventMessage event);
}
