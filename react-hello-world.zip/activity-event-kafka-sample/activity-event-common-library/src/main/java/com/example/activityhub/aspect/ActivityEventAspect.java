package com.example.activityhub.aspect;

import com.example.activityhub.annotation.ActivityEvent;
import com.example.activityhub.model.ActivityEventMessage;
import com.example.activityhub.publisher.ActivityEventPublisher;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

@Aspect
public class ActivityEventAspect {

    private static final Logger logger =
            LoggerFactory.getLogger(ActivityEventAspect.class);

    private final ActivityEventPublisher publisher;

    public ActivityEventAspect(ActivityEventPublisher publisher) {
        this.publisher = publisher;
    }

    @Before("@annotation(activityEvent)")
    public void logActivity(
            JoinPoint joinPoint,
            ActivityEvent activityEvent) {

        try {
            logger.info(
                    "Aspect thread={}",
                    Thread.currentThread().getName()
            );

            ActivityEventMessage event =
                    buildEvent(joinPoint, activityEvent);

            publisher.publish(event);
        } catch (Exception exception) {
            // Activity publishing must not break the business method.
            logger.warn(
                    "Failed to submit activity event",
                    exception
            );
        }
    }

    private ActivityEventMessage buildEvent(
            JoinPoint joinPoint,
            ActivityEvent annotation) {

        MethodSignature signature =
                (MethodSignature) joinPoint.getSignature();

        Method method = signature.getMethod();
        Parameter[] parameters = method.getParameters();
        Object[] values = joinPoint.getArgs();

        Map<String, Object> payload = new LinkedHashMap<>();

        for (int index = 0; index < parameters.length; index++) {
            payload.put(parameters[index].getName(), values[index]);
        }

        ActivityEventMessage event = new ActivityEventMessage();
        event.setEventId(UUID.randomUUID().toString());
        event.setEventDate(Instant.now());
        event.setEventName(annotation.eventName());
        event.setCategory(emptyToNull(annotation.category()));
        event.setEntityType(emptyToNull(annotation.entityType()));
        event.setContactType(emptyToNull(annotation.contactType()));
        event.setSource(resolveSource(annotation.source()));
        event.setEntityId(findArgument(
                annotation.entityIdArg(),
                parameters,
                values
        ));
        event.setContactId(findArgument(
                annotation.contactIdArg(),
                parameters,
                values
        ));
        event.setPayload(payload);

        return event;
    }

    private String findArgument(
            String argumentName,
            Parameter[] parameters,
            Object[] values) {

        if (argumentName == null || argumentName.isBlank()) {
            return null;
        }

        for (int index = 0; index < parameters.length; index++) {
            if (parameters[index].getName().equals(argumentName)) {
                Object value = values[index];
                return value == null ? null : value.toString();
            }
        }

        logger.warn(
                "Activity annotation argument '{}' was not found. Compile with -parameters.",
                argumentName
        );

        return null;
    }

    private String resolveSource(String source) {
        if (source != null && !source.isBlank()) {
            return source;
        }

        String applicationName =
                System.getProperty("spring.application.name");

        return applicationName == null
                ? "unknown"
                : applicationName;
    }

    private String emptyToNull(String value) {
        return value == null || value.isBlank()
                ? null
                : value;
    }
}
