package com.example.activityconsumer.service;

import com.example.activityconsumer.entity.ActivityEventEntity;
import com.example.activityconsumer.repository.ActivityEventRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ActivityEventTransactionalWriter {

    private final ActivityEventRepository repository;

    public ActivityEventTransactionalWriter(
            ActivityEventRepository repository) {
        this.repository = repository;
    }

    /**
     * A separate transaction boundary is intentional.
     *
     * If the unique event_id constraint is violated, only this inner
     * transaction is rolled back. The caller can safely recognize the
     * duplicate and return success to Kafka.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void insert(ActivityEventEntity entity) {
        repository.saveAndFlush(entity);
    }
}
