package com.example.activityconsumer.service;

import com.example.activityconsumer.entity.ActivityEventEntity;
import com.example.activityconsumer.repository.ActivityEventRepository;
import com.example.activityhub.model.ActivityEventMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class ActivityEventPersistenceService {

    private static final Logger logger =
            LoggerFactory.getLogger(ActivityEventPersistenceService.class);

    private final ActivityEventRepository repository;
    private final ActivityEventTransactionalWriter writer;
    private final ObjectMapper objectMapper;

    public ActivityEventPersistenceService(
            ActivityEventRepository repository,
            ActivityEventTransactionalWriter writer,
            ObjectMapper objectMapper) {

        this.repository = repository;
        this.writer = writer;
        this.objectMapper = objectMapper;
    }

    public void saveIdempotently(ActivityEventMessage event) {

        validate(event);

        // Fast-path check. The database unique constraint remains the final guard.
        if (repository.existsByEventId(event.getEventId())) {
            logger.info(
                    "Duplicate activity event ignored. eventId={}",
                    event.getEventId()
            );
            return;
        }

        ActivityEventEntity entity = map(event);

        try {
            writer.insert(entity);

            logger.info(
                    "Activity event saved. eventId={}",
                    event.getEventId()
            );
        } catch (DataIntegrityViolationException duplicateOrConstraintFailure) {

            // Confirm this is actually a duplicate before treating it as success.
            if (repository.existsByEventId(event.getEventId())) {
                logger.info(
                        "Concurrent duplicate activity event ignored. eventId={}",
                        event.getEventId()
                );
                return;
            }

            // A different database constraint failed; propagate so Kafka retries.
            throw duplicateOrConstraintFailure;
        }
    }

    private ActivityEventEntity map(ActivityEventMessage event) {

        ActivityEventEntity entity = new ActivityEventEntity();
        entity.setEventId(event.getEventId());
        entity.setEventDate(
                event.getEventDate() == null
                        ? Instant.now()
                        : event.getEventDate()
        );
        entity.setEventName(event.getEventName());
        entity.setCategory(event.getCategory());
        entity.setEntityType(event.getEntityType());
        entity.setEntityId(event.getEntityId());
        entity.setContactType(event.getContactType());
        entity.setContactId(event.getContactId());
        entity.setSource(event.getSource());
        entity.setSessionId(event.getSessionId());
        entity.setPayloadJson(toJson(event));
        entity.setCreatedAt(Instant.now());

        return entity;
    }

    private String toJson(ActivityEventMessage event) {
        try {
            return objectMapper.writeValueAsString(event.getPayload());
        } catch (JsonProcessingException exception) {
            throw new IllegalArgumentException(
                    "Unable to serialize activity payload. eventId="
                            + event.getEventId(),
                    exception
            );
        }
    }

    private void validate(ActivityEventMessage event) {
        if (event == null) {
            throw new IllegalArgumentException(
                    "Activity event must not be null"
            );
        }

        if (event.getEventId() == null
                || event.getEventId().isBlank()) {
            throw new IllegalArgumentException(
                    "Activity eventId must not be blank"
            );
        }

        if (event.getEventName() == null
                || event.getEventName().isBlank()) {
            throw new IllegalArgumentException(
                    "Activity eventName must not be blank. eventId="
                            + event.getEventId()
            );
        }
    }
}
