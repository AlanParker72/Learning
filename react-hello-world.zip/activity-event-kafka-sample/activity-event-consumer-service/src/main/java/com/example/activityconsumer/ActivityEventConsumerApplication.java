package com.example.activityconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.kafka.annotation.EnableKafka;

@EnableKafka
@SpringBootApplication
public class ActivityEventConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(
                ActivityEventConsumerApplication.class,
                args
        );
    }
}
