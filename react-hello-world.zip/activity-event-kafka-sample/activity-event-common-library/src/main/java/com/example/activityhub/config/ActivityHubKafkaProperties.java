package com.example.activityhub.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;

@ConfigurationProperties(prefix = "activityhub.kafka")
public class ActivityHubKafkaProperties {

    private String topic = "activity-events";
    private String dltTopic = "activity-events.DLT";
    private boolean warmupEnabled = true;
    private final Consumer consumer = new Consumer();

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getDltTopic() {
        return dltTopic;
    }

    public void setDltTopic(String dltTopic) {
        this.dltTopic = dltTopic;
    }

    public boolean isWarmupEnabled() {
        return warmupEnabled;
    }

    public void setWarmupEnabled(boolean warmupEnabled) {
        this.warmupEnabled = warmupEnabled;
    }

    public Consumer getConsumer() {
        return consumer;
    }

    public static class Consumer {
        private String groupId = "activity-event-db-writer";
        private int concurrency = 1;
        private long retryMaxAttempts = 3;
        private Duration retryBackoff = Duration.ofSeconds(1);

        public String getGroupId() {
            return groupId;
        }

        public void setGroupId(String groupId) {
            this.groupId = groupId;
        }

        public int getConcurrency() {
            return concurrency;
        }

        public void setConcurrency(int concurrency) {
            this.concurrency = concurrency;
        }

        public long getRetryMaxAttempts() {
            return retryMaxAttempts;
        }

        public void setRetryMaxAttempts(long retryMaxAttempts) {
            this.retryMaxAttempts = retryMaxAttempts;
        }

        public Duration getRetryBackoff() {
            return retryBackoff;
        }

        public void setRetryBackoff(Duration retryBackoff) {
            this.retryBackoff = retryBackoff;
        }
    }
}
