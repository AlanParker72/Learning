package com.example.activityhub.publisher;

import com.example.activityhub.config.ActivityHubKafkaProperties;
import com.example.activityhub.model.ActivityEventMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Async;

public class KafkaActivityEventPublisher implements ActivityEventPublisher {

    private static final Logger logger =
            LoggerFactory.getLogger(KafkaActivityEventPublisher.class);

    private final KafkaTemplate<String, ActivityEventMessage> kafkaTemplate;
    private final ActivityHubKafkaProperties properties;

    public KafkaActivityEventPublisher(
            KafkaTemplate<String, ActivityEventMessage> kafkaTemplate,
            ActivityHubKafkaProperties properties) {

        this.kafkaTemplate = kafkaTemplate;
        this.properties = properties;
    }

    @Override
    @Async
    public void publish(ActivityEventMessage event) {

        long startedAt = System.currentTimeMillis();

        logger.info(
                "Kafka publish started. eventId={}, thread={}",
                event.getEventId(),
                Thread.currentThread().getName()
        );

        String key = event.getSessionId() != null
                ? event.getSessionId()
                : event.getEventId();

        kafkaTemplate.send(properties.getTopic(), key, event)
                .whenComplete((result, exception) -> {

                    long duration =
                            System.currentTimeMillis() - startedAt;

                    if (exception != null) {
                        logger.error(
                                "Kafka publish failed. eventId={}, durationMs={}",
                                event.getEventId(),
                                duration,
                                exception
                        );
                    } else {
                        logger.info(
                                "Kafka publish successful. eventId={}, partition={}, offset={}, durationMs={}",
                                event.getEventId(),
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset(),
                                duration
                        );
                    }
                });
    }
}
