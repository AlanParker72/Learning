package com.example.activityhub.config;

import com.example.activityhub.model.ActivityEventMessage;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.autoconfigure.kafka.KafkaAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

@AutoConfiguration(after = KafkaAutoConfiguration.class)
@EnableConfigurationProperties(ActivityHubKafkaProperties.class)
public class ActivityEventKafkaConfiguration {

    @Bean("activityEventProducerFactory")
    @ConditionalOnMissingBean(name = "activityEventProducerFactory")
    public ProducerFactory<String, ActivityEventMessage> activityEventProducerFactory(
            KafkaProperties kafkaProperties) {

        Map<String, Object> properties =
                new HashMap<>(kafkaProperties.buildProducerProperties());

        properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        return new DefaultKafkaProducerFactory<>(properties);
    }

    @Bean("activityEventKafkaTemplate")
    @ConditionalOnMissingBean(name = "activityEventKafkaTemplate")
    public KafkaTemplate<String, ActivityEventMessage> activityEventKafkaTemplate(
            @Qualifier("activityEventProducerFactory")
            ProducerFactory<String, ActivityEventMessage> producerFactory) {

        return new KafkaTemplate<>(producerFactory);
    }

    @Bean("activityEventConsumerFactory")
    @ConditionalOnMissingBean(name = "activityEventConsumerFactory")
    public ConsumerFactory<String, ActivityEventMessage> activityEventConsumerFactory(
            KafkaProperties kafkaProperties,
            ActivityHubKafkaProperties activityProperties) {

        Map<String, Object> properties =
                new HashMap<>(kafkaProperties.buildConsumerProperties());

        properties.put(ConsumerConfig.GROUP_ID_CONFIG,
                activityProperties.getConsumer().getGroupId());
        properties.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        properties.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                ErrorHandlingDeserializer.class);
        properties.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                ErrorHandlingDeserializer.class);
        properties.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS,
                StringDeserializer.class);
        properties.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS,
                JsonDeserializer.class);
        properties.put(JsonDeserializer.VALUE_DEFAULT_TYPE,
                ActivityEventMessage.class.getName());
        properties.put(JsonDeserializer.TRUSTED_PACKAGES,
                "com.example.activityhub.model");

        return new DefaultKafkaConsumerFactory<>(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    public DefaultErrorHandler activityEventErrorHandler(
            @Qualifier("activityEventKafkaTemplate")
            KafkaTemplate<String, ActivityEventMessage> kafkaTemplate,
            ActivityHubKafkaProperties properties) {

        DeadLetterPublishingRecoverer recoverer =
                new DeadLetterPublishingRecoverer(
                        kafkaTemplate,
                        (record, exception) ->
                                new TopicPartition(
                                        properties.getDltTopic(),
                                        record.partition()
                                )
                );

        long interval = properties.getConsumer()
                .getRetryBackoff()
                .toMillis();

        long maxAttempts = properties.getConsumer()
                .getRetryMaxAttempts();

        long retriesAfterInitialAttempt = Math.max(0, maxAttempts - 1);

        return new DefaultErrorHandler(
                recoverer,
                new FixedBackOff(interval, retriesAfterInitialAttempt)
        );
    }

    @Bean("activityEventKafkaListenerContainerFactory")
    @ConditionalOnMissingBean(name = "activityEventKafkaListenerContainerFactory")
    public ConcurrentKafkaListenerContainerFactory<String, ActivityEventMessage>
            activityEventKafkaListenerContainerFactory(
                    @Qualifier("activityEventConsumerFactory")
                    ConsumerFactory<String, ActivityEventMessage> consumerFactory,
                    DefaultErrorHandler activityEventErrorHandler,
                    ActivityHubKafkaProperties properties) {

        ConcurrentKafkaListenerContainerFactory<String, ActivityEventMessage> factory =
                new ConcurrentKafkaListenerContainerFactory<>();

        factory.setConsumerFactory(consumerFactory);
        factory.setCommonErrorHandler(activityEventErrorHandler);
        factory.setConcurrency(properties.getConsumer().getConcurrency());
        factory.getContainerProperties()
                .setAckMode(ContainerProperties.AckMode.RECORD);

        return factory;
    }
}
