# Activity Event Kafka Sample

This ZIP contains two Maven modules:

1. `activity-event-common-library`
   - `@ActivityEvent` annotation and AOP aspect
   - asynchronous Kafka publisher
   - producer warm-up during application startup
   - producer and consumer Kafka factories
   - listener retry and dead-letter-topic configuration
   - shared `ActivityEventMessage`

2. `activity-event-consumer-service`
   - `@KafkaListener`
   - database persistence
   - idempotency using a unique `event_id`
   - duplicate handling across a separate transaction boundary
   - Flyway migration
   - H2 file database for a runnable example

## Important behavior

- `@Async` prevents Kafka producer initialization and publishing from blocking the Prospect request thread.
- Warm-up calls `producer.partitionsFor(topic)` during startup so the first real event does not pay the normal producer initialization cost.
- The consumer commits a record only after the listener completes successfully.
- Database errors propagate to Spring Kafka and are retried.
- After retries are exhausted, the record is sent to `<topic>.DLT`.
- `event_id` is unique. Re-delivered events do not create duplicate rows.

## Build

```bash
mvn clean package
```

## Run the consumer

Start Kafka first, then:

```bash
cd activity-event-consumer-service
mvn spring-boot:run
```

The default topic is:

```text
activity-events
```

The dead-letter topic is:

```text
activity-events.DLT
```

The consumer group is:

```text
activity-event-db-writer
```

## Use the common library in Prospect Management

Add the generated common-library dependency:

```xml
<dependency>
    <groupId>com.example.activityhub</groupId>
    <artifactId>activity-event-common-library</artifactId>
    <version>1.0.0-SNAPSHOT</version>
</dependency>
```

Annotate a Spring-managed business method:

```java
@ActivityEvent(
    eventName = "PROSPECT_SEARCHED",
    category = "READ",
    entityType = "PROSPECT",
    contactType = "PROSPECT",
    entityIdArg = "prospectId",
    contactIdArg = "prospectId"
)
public Prospect getProspectById(String prospectId) {
    // business logic
}
```

Compile with `-parameters` so Java parameter names such as `prospectId` are retained. Spring Boot's Maven plugin normally supports normal project compilation, but explicitly configure the Maven compiler plugin if your existing build strips parameter names.

## Production notes

- The sample uses H2 so it can run without an external database. Replace the datasource dependency and URL with your production database.
- Keep the unique database constraint even if you perform an `exists` check. The database constraint is the final idempotency protection.
- The default Spring async executor is used, matching the requested simple setup. Add a dedicated executor later if activity publishing needs isolation or bounded capacity.
- DLT topic auto-creation depends on your Kafka broker settings. In controlled environments, create both topics explicitly.
