package com.example.activityconsumer.repository;

import com.example.activityconsumer.entity.ActivityEventEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActivityEventRepository
        extends JpaRepository<ActivityEventEntity, Long> {

    boolean existsByEventId(String eventId);
}
